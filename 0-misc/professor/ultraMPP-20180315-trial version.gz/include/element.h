#include <boost/shared_array.hpp>
#include <boost/multi_array.hpp>

using namespace std ;

#ifndef __ELEMENT_H
#define __ELEMENT_H

class Node ;
class Face ;
class Cell ;
//class Domain;


class Node
{
	public:
		Node() ;
		~Node() ;
		int		id, local_id, type ;
		int		face_number ;
		int		cell_number ;

		boost::shared_array< Face* > face ;
		boost::shared_array< Cell* > cell ;
		boost::shared_array< double > alpha ;

		void set_id ( int g, int l ) ; //( global, local )
		void set_position ( double p1, double p2, double p3 ) ;
		void set_face_number ( int size ) ;
		void set_cell_number ( int size ) ;

		double	r[ 3 ] ;
} ;

class Face
{
	public:
		Face() ;
		~Face() ;
		int		mpi_id, id, local_id, type ;
string	Typename ;

		int	node_number ; /* How many nodes connected. */
		int	cell_number ; /* How many cells connected. */
		boost::shared_array < Node* > node ;
		boost::shared_array < Cell* > cell ;
		boost::shared_array < double > 	cell_sign ;

		void set_id ( int g, int l ) ; //( global, local )
		void set_type ( int t, string tn ) ;
		void set_position ( double p1, double p2, double p3 ) ;
		void set_node_number ( int size ) ;
		void set_cell_number ( int size ) ;

		/* dA is the face area */
		/* dr_c2c is the distance between two cell centers */
		/* r_fo[ 3 ] are the coordinates of cross point of the face and line bwtween cell centers */
		// r[ 3 ]			=	( x, y, z )
		// r_fo[ 3 ]		=	( r_fo(x), r_fo(y), r_fo(z) )
		// A[ 3 ]			=	( Ax, Ay, Az )
		// dA 				=	sqrt( Ax^2 + Ay^2 + Az^2 ) ;
		// nA[ 3 ]			=	( nx, ny, nz )
		// r_c2c[ 3 ]		=	( r_c1(x) - r_c0(x), r_c1(y) - r_c0(y), r_c1(z) - r_c0(z) )
		// dr_c2c 			=	dist( r_c1, r_c0 ) ;
		// r_c2f[ 0 ][ 3 ]	=	( r_f(x) - r_c0(x), r_f(y) - r_c0(y), r_f(z) - r_c0(z) )
		// dr_c2f[ 0 ]		=	dist( r_f, r_c0 )
		// r_c2fo[ 0 ][ 3 ]	=	( r_fo(x) - r_c0(x), r_fo(y) - r_c0(y), r_fo(z) - r_c0(z) )
		// dr_c2fo[ 0 ]		=	dist( r_fo, r_c0 )
		// r_fo2f[ 3 ]		=	( r_f(x) - r_fo(x), r_f(y) - r_fo(y), r_f(z) - r_fo(z) )
		// dr_cp2cp 		=	dist( r_c1', r_c0' ) = dr_c2fo_cos[ 0 ] + dr_c2fo_cos[ 1 ]

		double	r[ 3 ], r_fo[ 3 ] ;
		double	A[ 3 ], dA, nA[ 3 ], nAd, tA[ 2 ][ 3 ] ;
		double 	r_c2c[ 3 ], dr_c2c, er_c2c[ 3 ] ;
		double 	r_c2f[ 2 ][ 3 ], dr_c2f[ 2 ] ;
		double 	r_c2fo[ 2 ][ 3 ], dr_c2fo[ 2 ], dr_c2fo_cos[ 2 ] ;
		double 	r_fo2f[ 3 ], r_c2cp[ 2 ][ 3 ], dr_cp2cp ;

		double 	alpha_c2f[ 2 ], alpha_c2fo[ 2 ] ;
		double 	diffusion_coefficient_1st, diffusion_coefficient_2nd[ 2 ][ 3 ] ;

	private:
} ;


/*! \brief class Cell

@param id		The global ID of cell
@param local_id		The local ID of cell
@param volume		The cell volume
@param face_sign	The direction of the face in one cell, which might be \f$+1\f$ or \f$-1\f$. The sign is opposite to the neighbor cell cross this face.
@param face_index	The index is for the convenience to give an index to neighoor cell of a face. If the face_sign=1, the face_index will be 0, otherwise will be 1.
*/

class Cell
{
	public:
		Cell() ;
		~Cell() ;

		int		mpi_id, id, local_id, mesh_id, form, type ;
		int		node_number, face_number, cell_number ;
string	Typename ;

boost::shared_array < double > face_sign ;
		boost::shared_array < int >	face_index ;

		boost::shared_array < Node* > node ;
		boost::shared_array < Face* > face ;
		boost::shared_array < Cell* > cell ;

		// New version
		double 	volume ;
		double	r[ 3 ] ;

		boost::shared_array < vector<double> > A  ;
		boost::shared_array < vector<double> > nA ;

		void set_id ( int g, int l, int m ) ;  //( global, local, mesh )
		void set_type ( int t , string tn ) ;
		void set_position ( double p1, double p2, double p3 ) ;
		void set_volume ( double v ) ;

		void set_face_number ( int size ) ;
		void set_node_number ( int size ) ;
		void set_cell_number ( int size ) ;
} ;

double dist( double x1, double y1, double z1, double x2, double y2, double z2 ) ;
void check_neighbor_data( vector<int> *meshdata, int *table_mesh_local, vector<int> *neighbordata ) ;
void check_neighbor_data(int isize, int *meshdata, int *table_mesh_local, vector<int> *neighbordata );


#endif
