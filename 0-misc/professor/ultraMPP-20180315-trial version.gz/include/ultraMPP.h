#include <mpi.h>
#include "json.hpp"
#include "element.h"
#include <string>

#ifndef ULTRAMPP_H
#define ULTRAMPP_H


using namespace std ;
using nlohmann::json ;


struct mesh
{
	int 	mesh_tag ;
	int 	ndim ;
	string 	meshfile ;
	string 	geometry ;
	double 	min_cell_length ;


	double 	scale ;
	int 	cell_number ;
	int 	face_number ;
	int 	node_number ;

	int 	cell_number_with_overlapping_cell ;
	int 	face_number_with_overlapping_cell ;
	int 	node_number_with_overlapping_cell ;
} ;


class ultraMPP
{
	public:

	ultraMPP() ;
	~ultraMPP() ;

	int		myid, cpu_size ;

	json configuration_json, linear_solver_setting_json ;

//--
	int 	pc_type, solver_type ;
	double 	rtol;

	mesh 	Mesh ;

	void 	initial( int argc, char * argv[], int *_myid, int *_cpu_size ) ;

	void 	load_mesh( string jsonInput ) ;
	int 	get_dimension( ) ;
	int 	get_bc_mapping( string bc_name ) ;

	int 	set_parallel_cell_data( double **ptr, string data_name ) ;
	int 	set_face_data( double **ptr, string data_name ) ;
	int 	set_node_data( double **ptr, string data_name ) ;

	void 	syn_parallel_cell_data( int iNum_Tag ) ;
	void 	syn_parallel_cell_data( int iNum_Tag1, int iNum_Tag2 ) ;

	void 	before_matrix_construction() ;
	void 	add_entry_in_matrix( int _row_th, int _col_th, double _item ) ;
	void 	finish_matrix_construction() ;

	void 	before_source_term_construction() ;
	void 	add_entry_in_source_term( int _row_th, double _item ) ;
	void 	finish_source_term_construction() ;

	void 	get_solution( double *_sol ) ;
	void 	get_gradient( double *face_data, double **EF) ;
	void 	get_gradient_least( double *face_data, double **EF) ;


	void 	get_source_term( double *_source ) ;
	void 	set_output( string filename ) ;
	void 	set_output( int iTag ) ;
	void 	write_output( string iTag ) ;

	void 	apply_linear_solver_setting();

	void    add_laplacian_op( double scale );
	void    set_bc_value(int bc_tag, double bc_value, double *face_data );
	void    set_source_term( double *charge, double *face_bc_value );
	void    add_non_orthogornal_correction(double **EF);

	Node 	*get_node( int nodeid ) ;
	Face 	*get_face( int faceid ) ;
	Cell 	*get_cell( int cellid ) ;

	protected:

	private:
} ;

#endif // ULTRAMPP_H
