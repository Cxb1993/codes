#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <mpi.h>
#include "json.hpp"
#include "ultraMPP.h"

using namespace std ;
using nlohmann::json ;

int cpu_size, myid ;

int main( int argc, char * argv[] )
{
//--example code of two dimensional poisson equation solver for structured mesh
//--define the PDE solver
	ultraMPP PDE_solver ;

//--For access the element information
	Cell *cell;
	Face *face;
	Node *node;

//--Initial the PDE solver and load the mesh
	PDE_solver.initial( argc,argv, &myid, &cpu_size ) ;
	PDE_solver.load_mesh( "JsonInput.json" ) ;

//--content in JsonInput.json
/*
{
"mesh":
	{
		"geometry": "2D",
		"scale": 1.0,
		"structured_mesh":
		{
			"nx": 101,
			"ny": 101,
			"dx": 0.001,
			"dy": 0.001,
			"boundary_settings": [ "Wall_1", "Wall_2", "Neumann", "Neumann" ]
		}
	}
}
*/

	int 	Neumann_bc_tag    = PDE_solver.get_bc_mapping( "Neumann") ;
	int 	Dirichlet_bc_tag1 = PDE_solver.get_bc_mapping( "Wall_1" ) ;
	int 	Dirichlet_bc_tag2 = PDE_solver.get_bc_mapping( "Wall_2" ) ;

//--define the the cell based data array
	int ndim = PDE_solver.Mesh.ndim;
	double *potential, *charge, *cpiID;
	double *face_data;

	int Tag_EF[ndim];
	double **EF;

	EF = new double*[ndim];

	int Tag_Cha = PDE_solver.set_parallel_cell_data(&charge, "ChargeDen");
	int Tag_pot = PDE_solver.set_parallel_cell_data(&potential, "Potential");
	for( int i = 0; i < ndim; i++)
		Tag_EF[i] = PDE_solver.set_parallel_cell_data( &EF[i], "EF");

	int Tag_Cpu = PDE_solver.set_parallel_cell_data(&cpiID, "cpuid");
	int Tag_Fac = PDE_solver.set_face_data(&face_data, "face_data");

//--Set output data
	PDE_solver.set_output("test.dat");
	PDE_solver.set_output(Tag_Cha);
	PDE_solver.set_output(Tag_pot);

	for( int i = 0; i < ndim; i++)
		PDE_solver.set_output(Tag_EF[i]);

	PDE_solver.set_output(Tag_Cpu);

	double entry_value;
	double Eps = 8.8541878176e-12; // unit: (F/m), (C^2 / N / m^2)
	double E_Charge   = 1.602176462e-19; // Coulomb

//--Set cpu ID for each cell ( example of setting data into a cell based array )
	for ( int cth = 0 ; cth < PDE_solver.Mesh.cell_number ; cth++ )
	{
//------do something
		cell 			=	PDE_solver.get_cell( cth ) ;
		//cell based array, get cell information through "Cell" element
		cpiID[ cth ]	=	cell->mpi_id ;
		charge[ cth ]	=	1.0e16 ;
	}

	PDE_solver.apply_linear_solver_setting();
	PDE_solver.before_matrix_construction() ;
//---------------------------------------------------
	for ( int cth = 0 ; cth < PDE_solver.Mesh.cell_number; cth++ )
	{
	//--do something
		cell 	=	PDE_solver.get_cell( cth ) ;

		//--for interior face
		for ( int fth = 0 ; fth < cell->cell_number ; fth++ )
		{
			entry_value 	=	cell->face[ fth ]->dA / cell->face[ fth ]->dr_c2c ;
			PDE_solver.add_entry_in_matrix( cth, cell->id,             - entry_value ) ;
			PDE_solver.add_entry_in_matrix( cth, cell->cell[ fth ]->id,  entry_value ) ;
		}

		//--for boundary face
		for ( int fth = cell->cell_number ; fth < cell->face_number ; fth++ )
		{
			entry_value 	=	cell->face[ fth ]->dA / cell->face[ fth ]->dr_c2c ;
			if ( cell->face[ fth ]->type == Neumann_bc_tag )
			{

			} else if ( cell->face[ fth ]->type == Dirichlet_bc_tag1)
			{
				PDE_solver.add_entry_in_matrix( cth, cell->id, - entry_value ) ;
			} else if( cell->face[ fth ]->type == Dirichlet_bc_tag2 )
			{
				PDE_solver.add_entry_in_matrix( cth, cell->id, - entry_value ) ;
			}
		}
	}
//---------------------------------------------------
	PDE_solver.finish_matrix_construction() ;

//--define the boundary condition
	for ( int fth = 0 ; fth < PDE_solver.Mesh.face_number; fth++ )
	{
		face_data[ fth ] = 0.0 ;
		face = PDE_solver.get_face( fth ) ;

		if ( face->type == Dirichlet_bc_tag1 )
		{
			face_data[ fth ]	=	0.0 ;
		} else if ( face->type == Dirichlet_bc_tag2 )
		{
			face_data[ fth ]	=	0.0 ;
		}
	}
//--
	PDE_solver.before_source_term_construction() ;
//---------------------------------------------------
	for ( int cth = 0 ; cth < PDE_solver.Mesh.cell_number ; cth++ )
	{
	//--do something
		cell 	=	PDE_solver.get_cell( cth ) ;
		PDE_solver.add_entry_in_source_term( cth, - E_Charge * cell->volume * charge[ cth ] / Eps ) ;
		//--for interior face
		for ( int fth = 0 ; fth < cell->cell_number ; fth++ )
		{
		}

		//--for boundary face
		for ( int fth = cell->cell_number ; fth < cell->face_number ; fth++ )
		{
			entry_value 	=	cell->face[ fth ]->dA / cell->face[ fth ]->dr_c2c ;

			if ( cell->face[ fth ]->type == Neumann_bc_tag )
			{

			} else if ( cell->face[ fth ]->type == Dirichlet_bc_tag1 | cell->face[ fth ]->type == Dirichlet_bc_tag2 )
			{
				PDE_solver.add_entry_in_source_term( cth, - entry_value * face_data[cell->face[ fth ]->local_id ] ) ;
			}
		}
	}

//---------------------------------------------------
	PDE_solver.finish_source_term_construction() ;

	PDE_solver.get_solution( potential ) ;
	PDE_solver.get_gradient( face_data, EF) ;

	for ( int i = 0; i < ndim; i++)
	for ( int ith = 0 ; ith < PDE_solver.Mesh.cell_number ; ith++ ) EF[ i ][ ith ] = - EF[ i ][ ith ] ;

	PDE_solver.write_output( "Time0" ) ;
//----

	return 0 ;
}
