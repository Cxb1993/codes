#include <string>

using namespace std ; 

#ifndef __ULTRAMPP_EULER_02_H
#define __ULTRAMPP_EULER_02_H

class EulerRoe
{
	public:
		double 	dT, CFL, tolerance, gamma ;
		double 	rho_inf, Ma_inf, vector_inf[ 3 ], v_inf[ 3 ], P_inf, a_inf, H_inf, E_inf ;

		int 	timestep, dump_frequency ;

		void 	Simulation_condition( string filename ) ;
		void 	Roe_Flux( double *Flux, int ndim, int unknownNum, double **U, Cell *cell, Face *face, int fth ) ;
		bool 	Calculate_MaxTol( double *MaxTol, int unknownNum, int cellNum, double **_tol ) ;

	private:
} ;

#endif