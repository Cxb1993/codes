#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <mpi.h>
#include "json.hpp"
#include "ultraMPP.h"

using namespace std ;
using nlohmann::json ;

int cpu_size, myid ;

int main( int argc, char * argv[] )
{
	ultraMPP 	Euler_solver ;

	double  t_max = 0.5 ;
	int 	Timesteps = 150 ;
	double  dt = t_max / Timesteps ;
	int 	dump_frequancy = 10 ;

	double 	c[ 3 ] ;
	c[ 0 ]	=	0.5 ;
	c[ 1 ]	=	0.0 ;
	c[ 2 ]	=	0.0 ;

	string	tmp[ 2 ][ 3 ] ;
	tmp[ 0 ][ 0 ]	=	"U" ;
	tmp[ 0 ][ 1 ]	=	"V" ;
	tmp[ 0 ][ 2 ]	=	"W" ;
	tmp[ 1 ][ 0 ]	=	"x" ;
	tmp[ 1 ][ 1 ]	=	"y" ;
	tmp[ 1 ][ 2 ]	=	"z" ;

	//--For access the element information
	Cell 	*cell ;
	Face 	*face ;
	Node 	*node ;
	double 	entry_value, source_value ;

	//--Initial the PDE solver and load the mesh
	Euler_solver.initial( argc,argv, &myid, &cpu_size ) ;
	Euler_solver.load_mesh( "EulerInput_c1.json" ) ;

	//--content in EulerInput.json
	/*
	{
		"mesh":
		{
			"geometry": "2D",
			"scale": 1.0,
			"structured_mesh":
			{
				"nx": 51,
				"ny": 51,
				"dx": 0.04,
				"dy": 0.04,
				"boundary_settings": [ "D_1", "D_2", "Neumann", "Neumann" ]
			}
		}
	}
	*/

	int 	upwind_cell, fth_cth ;

	int 	ndim 			  =	Euler_solver.Mesh.ndim ;
	int 	Neumann_bc_tag    =	Euler_solver.get_bc_mapping( "Neumann") ;
	int 	Dirichlet_bc_tag1 =	Euler_solver.get_bc_mapping( "D_1" ) ;
	int 	Dirichlet_bc_tag2 =	Euler_solver.get_bc_mapping( "D_2" ) ;

	//--define the the cell based data array
	double 	*u[ ndim ], *pre_u[ ndim ], *grad_u[ ndim ][ ndim ], *cpuID ;

	int 	Tag_u[ ndim ], Tag_pre_u[ ndim ], Tag_grad_u[ ndim ][ ndim ] ;

	for ( int kth = 0 ; kth < ndim ; kth++ )
	{
		Tag_u[ kth ] 		=	Euler_solver.set_parallel_cell_data( &u[ kth ], tmp[ 0 ][ kth ] ) ;
		Tag_pre_u[ kth ] 	=	Euler_solver.set_parallel_cell_data( &pre_u[ kth ], "pre_" + tmp[ 0 ][ kth ] ) ;
		for ( int kkth = 0 ; kkth < ndim ; kkth++ )
			Tag_grad_u[ kth ][ kkth ] =	Euler_solver.set_parallel_cell_data( &grad_u[ kth ][ kkth ], "grad_" + tmp[ 0 ][ kth ] + tmp[ 1 ][ kkth ] ) ;
	}

	int 	Tag_cpu 	=	Euler_solver.set_parallel_cell_data( &cpuID, "cpuid" ) ;

	//--define the the face based data array
	double 	*face_u[ ndim ] ;
	int 	Tag_face_u[ ndim ] ;

	for ( int kth = 0 ; kth < ndim ; kth++ )
		Tag_face_u[ kth ] 	=	Euler_solver.set_face_data( &face_u[ kth ], "face_" + tmp[ 0 ][ kth ] ) ;

	//--Set output data
	Euler_solver.set_output( "EulerData_c1.dat" ) ;
	for ( int kth = 0 ; kth < ndim ; kth++ )
		Euler_solver.set_output( Tag_u[ kth ] ) ;
	Euler_solver.set_output( Tag_cpu ) ;

	//--Set cpu ID for each cell ( example of setting data into a cell based array )
	for ( int cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
	{
		//cell based array, get cell information through "Cell" element
		cell 			=	Euler_solver.get_cell( cth ) ;

		cpuID[ cth ]	=	cell->mpi_id ;

		if ( cell->r[ 0 ] > 0.5 && cell->r[ 0 ] < 1.0 )
		{
			u[ 0 ][ cth ]	=	2.0 ;
		} else
		{
			u[ 0 ][ cth ]	=	1.0 ;
		}
		u[ 1 ][ cth ]	=	0.0 ;

		pre_u[ 0 ][ cth ]	=	u[ 0 ][ cth ] ;
		pre_u[ 1 ][ cth ]	=	u[ 1 ][ cth ] ;
	}

	// update ghost cell value
	for ( int kth = 0 ; kth < ndim ; kth++ )
		Euler_solver.syn_parallel_cell_data( Tag_u[ kth ] ) ;

	//face based array, get cell information through "Face" element
	for ( int fth = 0 ; fth < Euler_solver.Mesh.face_number ; fth++ )
	{
		face 	=	Euler_solver.get_face( fth ) ;

		face_u[ 0 ][ fth ]	=	0.0 ;
		face_u[ 1 ][ fth ]	=	0.0 ;

		if ( face->Typename == "D_1" )
		{
			face_u[ 0 ][ fth ]	=	1.0 ;
		} else if ( face->Typename == "D_2" )
		{
			face_u[ 0 ][ fth ]	=	1.0 ;
		}
	}

	// dump initial data
	Euler_solver.write_output( "TS_init" ) ;

	stringstream 	sstr ;
	string 			zonename ;

	for ( int TS = 1 ; TS <= Timesteps ; TS++ )
	{
		for ( int kth = 0 ; kth < ndim ; kth++ )
		{
/*
			// calculate cell gradient
			Euler_solver.Get_Gradient( face_u[ kth ], grad_u[ kth ][ 0 ], grad_u[ kth ][ 1 ], nullptr ) ;

			// update ghost cell value
			for ( int kkth = 0 ; kkth < ndim ; kkth++ )
				Euler_solver.syn_parallel_cell_data( Tag_grad_u[ kth ][ kkth ] ) ;
*/

			// build Matrix A & B
			Euler_solver.before_matrix_construction() ;
			Euler_solver.before_source_term_construction() ;
			for ( int cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
			{
				cell 	=	Euler_solver.get_cell( cth ) ;

				Euler_solver.add_entry_in_matrix( cth, cell->id, 1.0 / dt * cell->volume ) ;
				Euler_solver.add_entry_in_source_term( cth, pre_u[ kth ][ cth ] / dt * cell->volume ) ;

				//--for interior face
				for ( int fth = 0 ; fth < cell->cell_number ; fth++ )
				{
					entry_value 	=	0.0 ;
					for ( int kth = 0 ; kth < ndim ; kth++ )
						entry_value 	+=	c[ kth ] * cell->A[ fth ][ kth ] ;

					// cell[ cth ]
					fth_cth			=	cell->face_index[ fth ] ;

					if ( entry_value >= 0.0 )
					{
						upwind_cell 	=	cth ;
						Euler_solver.add_entry_in_matrix( cth, cell->id, entry_value ) ;
					} else
					{
						upwind_cell 	=	cell->cell[ fth ]->local_id ;
						Euler_solver.add_entry_in_matrix( cth, cell->cell[ fth ]->id, entry_value ) ;
					}
/*
					source_value 	=	0.0 ;
					for ( int kkth = 0 ; kkth < ndim ; kkth++ )
						source_value +=	entry_value * grad_u[ kth ][ kkth ][ upwind_cell ] * cell->face[ fth ]->r_c2f[ kth ][ fth_cth ] ;
					Euler_solver.add_entry_in_source_term( cth, - source_value ) ;
*/					
				}

				//--for boundary face
				for ( int fth = cell->cell_number ; fth < cell->face_number ; fth++ )
				{
					entry_value 	=	0.0 ;
					for ( int kth = 0 ; kth < ndim ; kth++ )
						entry_value 	+=	c[ kth ] * cell->A[ fth ][ kth ] ;

					if ( cell->face[ fth ]->type == Neumann_bc_tag )
					{
						Euler_solver.add_entry_in_matrix( cth, cell->id, entry_value ) ;
					} else if ( cell->face[ fth ]->type == Dirichlet_bc_tag1 )
					{
						Euler_solver.add_entry_in_source_term( cth, - entry_value * face_u[ kth ][ cell->face[ fth ]->local_id ] ) ;
					} else if( cell->face[ fth ]->type == Dirichlet_bc_tag2 )
					{
						Euler_solver.add_entry_in_source_term( cth, - entry_value * face_u[ kth ][ cell->face[ fth ]->local_id ] ) ;
					}
				}
			}
			Euler_solver.finish_matrix_construction() ;
			Euler_solver.finish_source_term_construction() ;

			Euler_solver.get_solution( u[ kth ] ) ;
			Euler_solver.syn_parallel_cell_data( Tag_u[ kth ] ) ;

			for ( int cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
				pre_u[ kth ][ cth ]	=	u[ kth ][ cth ] ;
		}

		if ( TS % dump_frequancy == 0 || TS == Timesteps )
		{
			sstr.str("") ;
			sstr.clear() ;
			sstr 		<<	TS ;
			zonename 	=	"Timestep_" + sstr.str() ;
			Euler_solver.write_output( zonename ) ;
		}
	}

	return 0 ;
}