#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <mpi.h>
#include "json.hpp"
#include "ultraMPP.h"
#include "ultraMPP_Euler_c2.h"

using namespace std ;
using nlohmann::json ;

int cpu_size, myid ;

//===================================================================================================================================================================
//					example code of 2D/3D Euler equation solver
//===================================================================================================================================================================
int main( int argc, char * argv[] )
{
	ultraMPP 	Euler_solver ;
	EulerRoe 	euler ;

	int 		cth, fth, kth, buffer_int ;
	double 		buffer[ 2 ] ;
	bool 		flg_steady ;

	//--For access the element information
	Cell 		*cell ;
	Face 		*face ;
	Node 		*node ;

	// Initial the PDE solver and load the mesh
	Euler_solver.initial( argc,argv, &myid, &cpu_size ) ;
	Euler_solver.load_mesh( "EulerInput_c2.json" ) ;

	// Read simulation condition
	euler.Simulation_condition( "EulerInput_c2.json" ) ;

	int 	ndim 		=	Euler_solver.Mesh.ndim ;
	int 	unknownNum 	=	2 + ndim ;
	string	U_name[ unknownNum ] ;

	if ( ndim == 3 )
	{
		U_name[ 0 ]	=	"Rho" ;
		U_name[ 1 ]	=	"RhoU" ;
		U_name[ 2 ]	=	"RhoV" ;
		U_name[ 3 ]	=	"RhoW" ;
		U_name[ 4 ]	=	"RhoE" ;
	} else
	{
		U_name[ 0 ]	=	"Rho" ;
		U_name[ 1 ]	=	"RhoU" ;
		U_name[ 2 ]	=	"RhoV" ;
		U_name[ 3 ]	=	"RhoE" ;
	}

	//--define the the cell based data array
	double 	**U, **pre_U, **Residual, **Tolerance ;
	double 	*ao, *Ma, *P, *cpuID ;

	int 	Tag_U[ unknownNum ], Tag_pre_U[ unknownNum ], Tag_Residual[ unknownNum ], Tag_Tolerance[ unknownNum ] ;
	int 	Tag_ao, Tag_Ma, Tag_P, Tag_cpu ;

	U 			=	new double * [ unknownNum ] ;
	pre_U 		=	new double * [ unknownNum ] ;
	Residual 	=	new double * [ unknownNum ] ;
	Tolerance 	=	new double * [ unknownNum ] ;

	for ( kth = 0 ; kth < unknownNum ; kth++ )
	{
		Tag_U[ kth ] 			=	Euler_solver.set_parallel_cell_data( &U[ kth ], U_name[ kth ] ) ;
		Tag_pre_U[ kth ] 		=	Euler_solver.set_parallel_cell_data( &pre_U[ kth ], "pre_" + U_name[ kth ] ) ;
		Tag_Residual[ kth ]		=	Euler_solver.set_parallel_cell_data( &Residual[ kth ], "Residual_" + U_name[ kth ] ) ;
		Tag_Tolerance[ kth ]	=	Euler_solver.set_parallel_cell_data( &Tolerance[ kth ], "Tolerance_" + U_name[ kth ] ) ;
	}

	Tag_ao 		=	Euler_solver.set_parallel_cell_data( &ao, "Sound speed" ) ;
	Tag_Ma 		=	Euler_solver.set_parallel_cell_data( &Ma, "Mach number" ) ;
	Tag_P 		=	Euler_solver.set_parallel_cell_data( &P, "Pressure" ) ;
	Tag_cpu 	=	Euler_solver.set_parallel_cell_data( &cpuID, "cpuid" ) ;

	double 	Flux[ unknownNum ], MaxTol[ unknownNum ] ;

	// Set output data
	Euler_solver.set_output( "EulerData_c2.dat" ) ;
	for ( kth = 0 ; kth < unknownNum ; kth++ )
		Euler_solver.set_output( Tag_U[ kth ] ) ;
	
	Euler_solver.set_output( Tag_Ma ) ;
	Euler_solver.set_output( Tag_ao ) ;
	Euler_solver.set_output( Tag_P ) ;

	for ( kth = 0 ; kth < unknownNum ; kth++ )	
		Euler_solver.set_output( Tag_Residual[ kth ] ) ;

	for ( kth = 0 ; kth < unknownNum ; kth++ )	
		Euler_solver.set_output( Tag_Tolerance[ kth ] ) ;
	Euler_solver.set_output( Tag_cpu ) ;

	double dt ;
	buffer[ 0 ]	=	0.0 ;
	for ( kth = 0 ; kth < ndim ; kth++ )
		buffer[ 0 ]	+=	euler.v_inf[ kth ] * euler.v_inf[ kth ] ;
	dt =	0.5 * euler.CFL * Euler_solver.Mesh.min_cell_length / ( buffer[ 0 ] + sqrt( euler.gamma * euler.P_inf / euler.rho_inf ) ) ;

	// Initial conditions
	for ( cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
	{
		// Cell based array, get cell information through "Cell" element
		cell 			=	Euler_solver.get_cell( cth ) ;

		cpuID[ cth ]	=	cell->mpi_id ;

		buffer[ 1 ]		=	0.0 ;
		U[ 0 ][ cth ]	=	euler.rho_inf ;
		for ( kth = 0 ; kth < ndim ; kth++ )
		{
			U[ kth + 1 ][ cth ]	=	U[ 0 ][ cth ] * euler.v_inf[ kth ] ;
			buffer[ 1 ]			+=	U[ kth + 1 ][ cth ] * U[ kth + 1 ][ cth ] ;
		}

		U[ unknownNum - 1 ][ cth ]	=	euler.P_inf / ( euler.gamma - 1.0 ) + 0.5 * U[ 0 ][ cth ] * buffer[ 1 ] ;

		P[ cth ]	=	euler.P_inf ;
		ao[ cth ] 	=	sqrt( euler.gamma * P[ cth ] / U[ 0 ][ cth ] ) ;
		Ma[ cth ] 	=	buffer[ 1 ] / ao[ cth ] ;

		for ( kth = 0 ; kth < unknownNum ; kth++ )
		{
			pre_U[ kth ][ cth ]		=	U[ kth ][ cth ] ;
			Residual[ kth ][ cth ]	=	0.0 ;
			Tolerance[ kth ][ cth ]	=	0.0 ;
		}
	}

	// Update ghost cell value
	for ( kth = 0 ; kth < unknownNum ; kth++ )
		Euler_solver.syn_parallel_cell_data( Tag_U[ kth ] ) ;

	// Dump initial data
	Euler_solver.write_output( "TS_0" ) ;

	int 			TS ;
	stringstream 	sstr ;
	string 			zonename ;

	for ( TS = 1 ; TS <= euler.timestep ; TS++ )	
	{		
		// Calculate Residual
		for ( cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
		{
			cell 	=	Euler_solver.get_cell( cth ) ;

			for ( kth = 0 ; kth < unknownNum ; kth++ )
				Residual[ kth ][ cth ]	=	0.0 ;

			for ( fth = 0 ; fth < cell->face_number ; fth++ )
			{
				face 	=	Euler_solver.get_face( cell->face[ fth ]->local_id ) ;

				euler.Roe_Flux( Flux, ndim, unknownNum, U, cell, face, fth ) ;

				for ( kth = 0 ; kth < unknownNum ; kth++ )
					Residual[ kth ][ cth ]	+=	Flux[ kth ]	* face->dA ;
			}
		}

		// Time integral
		for ( cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
		{
			cell 	=	Euler_solver.get_cell( cth ) ;

			for ( kth = 0 ; kth < unknownNum ; kth++ )
			{
				Tolerance[ kth ][ cth ]	=	dt * Residual[ kth ][ cth ] / cell->volume ;

				U[ kth ][ cth ]			=	pre_U[ kth ][ cth ] - Tolerance[ kth ][ cth ] ;

				if ( fabs( pre_U[ kth ][ cth ] ) > 1.0e-10 )
				{
					Tolerance[ kth ][ cth ]	=	fabs( Tolerance[ kth ][ cth ] / pre_U[ kth ][ cth ] ) ;					
				} else
				{
					Tolerance[ kth ][ cth ]	=	0.0 ;
				}
			}		
		}

		// Calculat other flow parameters
		for ( cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
		{
			cell 	=	Euler_solver.get_cell( cth ) ;

			buffer[ 1 ] 	=	0.0 ;
			for ( kth = 0 ; kth < ndim ; kth++ )
				buffer[ 1 ] +=	pow( U[ kth + 1 ][ cth ] / U[ 0 ][ cth ], 2.0 ) ;
			buffer[ 1 ] 	=	sqrt( buffer[ 1 ] ) ;

			P[ cth ]	=	( euler.gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cth ] - 0.5 * U[ 0 ][ cth ] * ( buffer[ 1 ] * buffer[ 1 ] ) ) ;
			ao[ cth ] 	=	sqrt( euler.gamma * P[ cth ] / U[ 0 ][ cth ] ) ;
			Ma[ cth ] 	=	buffer[ 1 ] / ao[ cth ] ;
		}
		// Calculate Max. Residual
		flg_steady =	euler.Calculate_MaxTol( MaxTol, unknownNum, Euler_solver.Mesh.cell_number, Tolerance ) ;
		
		// Dump data
		if ( TS % euler.dump_frequency == 0 || ( flg_steady && TS > 10 ) )
		{	
			sstr.str("") ;
			sstr.clear() ;
			sstr 		<<	TS ;
			zonename 	=	"TS_" + sstr.str() ;
			Euler_solver.write_output( zonename ) ;

			if ( flg_steady && TS > 10 )
				break ;
		}

		// Update ghost cell value
		for ( kth = 0 ; kth < unknownNum ; kth++ )
		{
			Euler_solver.syn_parallel_cell_data( Tag_U[ kth ] ) ;
			for ( cth = 0 ; cth < Euler_solver.Mesh.cell_number ; cth++ )
				pre_U[ kth ][ cth ]	=	U[ kth ][ cth ] ;
		}
	}

	return 0 ;
}

void EulerRoe::Simulation_condition( string filename )
{
	json 	configuration, config ;
	ifstream jsonFile ;
	jsonFile.open( filename, ifstream::in ) ;
	jsonFile >> configuration ;

	if ( configuration.find( "simulation_condition" ) != configuration.end() )
	{
		config = configuration[ "simulation_condition" ] ;
	} else
	{
		cout << "Error: without 'simulation_condition' " ;
		exit( -1 ) ;
	}

	int 	kth ;
	double 	buffer[ 2 ] ;

	// default setting
	dT 				=	1.0e-05 ;
	CFL 			=	0.2 ;
	tolerance 		=	1.0e-10 ;

	gamma			=	1.4 ;
	rho_inf			=	1.0 ;
	Ma_inf			=	1.6 ;

	vector_inf[ 0 ]	=	1.0 ;
	vector_inf[ 1 ]	=	0.0 ;
	vector_inf[ 2 ]	=	0.0 ;

	timestep 		=	1000 ;
	dump_frequency 	=	100 ;

	buffer[ 0 ] =	0.0 ;
	for ( int i = 0 ; i < 3 ; i++ )
		buffer[ 0 ] 	+=	vector_inf[ i ] * vector_inf[ i ] ;
	buffer[ 0 ]	=	sqrt( buffer[ 0 ] ) ;

	if ( config.find( "dT" ) != config.end() )
		dT	=	config[ "dT" ] ;

	if ( config.find( "CFL" ) != config.end() )
		CFL	=	config[ "CFL" ] ;

	if ( config.find( "gamma" ) != config.end() )
		gamma	=	config[ "gamma" ] ;

	if ( config.find( "rho_inf" ) != config.end() )
		rho_inf	=	config[ "rho_inf" ] ;

	if ( config.find( "Ma_inf" ) != config.end() )
		Ma_inf	=	config[ "Ma_inf" ] ;

	if ( config.find( "vector_inf" ) != config.end() )
	{
		buffer[ 0 ] =	0.0 ;
		for ( kth = 0 ; kth < 3 ; kth++ )
		{
			vector_inf[ kth ]	=	config[ "vector_inf" ][ kth ] ;
			buffer[ 0 ] 	+=	vector_inf[ kth ] * vector_inf[ kth ] ;
		}

		if ( buffer[ 0 ] == 0.0 )
		{
			cout << "Inlet_vector setting failed." << endl ;
			exit( -1 ) ;
		} else
		{
			buffer[ 0 ] 	=	sqrt( buffer[ 0 ] ) ;
		}
	}

	if ( config.find( "timestep" ) != config.end() )
		timestep 	=	config[ "timestep" ] ;

	if ( config.find( "dump_frequency" ) != config.end() )
		dump_frequency 	=	config[ "dump_frequency" ] ;

	if ( config.find( "tolerance" ) != config.end() )
		tolerance 	=	config[ "tolerance" ] ;

	buffer[ 1 ]	=	0.0 ;
	for ( kth = 0 ; kth < 3 ; kth++ )
	{
		v_inf[ kth ] =	Ma_inf * vector_inf[ kth ] / buffer[ 0 ] ;
		buffer[ 1 ]	+=	v_inf[ kth ] * v_inf[ kth ] ;
	}

	P_inf	=	1.0 / gamma ;
	a_inf	=	sqrt( gamma * P_inf / rho_inf ) ;
	H_inf	=	a_inf * a_inf / ( gamma - 1.0 ) + 0.5 * buffer[ 1 ] ;
	E_inf 	=	pow( rho_inf, gamma ) / P_inf ;
}

void EulerRoe::Roe_Flux( double *Flux, int ndim, int unknownNum, double **U, Cell *cell, Face *face, int fth )
{
	//Reference: http://www.cfdbooks.com/
	int 	cid[ 2 ] ;
	double 	nA[ 3 ], tA[ ndim - 1 ][ 3 ] ;
	int 	kth, kkth, dth, ddth, fth_cth = cell->face_index[ fth ] ;
	string 	face_Typename = face->Typename ;

	double 	rho[ 3 ], v[ 3 ][ 3 ], vn[ 3 ], vt[ 2 ][ 3 ], p[ 3 ], a[ 3 ], H[ 3 ] ;
  	double 	RT, drho, dp, dvn, dvt[ 2 ], V2[ 2 ] ;
	double 	LdU[ unknownNum ], ws[ unknownNum ], dws[ unknownNum ], Rv[ unknownNum ][ unknownNum ], Diss[ unknownNum ] ;
  	double 	F[ unknownNum ][ 2 ] ;

  	cid[ 0 ] 	=	cell->local_id ;
  	if ( face->cell_number > 1 )
  		cid[ 1 ] 	=	face->cell[ 1 - fth_cth ]->local_id ;

  	for ( dth = 0 ; dth < ndim ; dth++ )
  	{
  		nA[ dth ]	=	cell->nA[ fth ][ dth ] ;

  		for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
	 		tA[ ddth ][ dth ]	=	cell->face_sign[ fth ] * face->tA[ ddth ][ dth ] ;
  	}

	if ( face_Typename == "Bulk" )
	{
    	// Left & Right state
    	for ( kth = 0 ; kth < 2 ; kth++ )
    	{
    		rho[ kth ] 	=	U[ 0 ][ cid[ kth ] ] ;

    		V2[ 0 ] 	=	0.0 ;
    		vn[ kth ]	=	0.0 ;
			for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
    			vt[ ddth ][ kth ]	=	0.0 ;

    		for ( dth = 0 ; dth < ndim ; dth++ )
    		{
    			v[ dth ][ kth ]	=	U[ dth + 1 ][ cid[ kth ] ] / U[ 0 ][ cid[ kth ] ] ;

				V2[ 0 ]		+=	v[ dth ][ kth ] * v[ dth ][ kth ] ;
				vn[ kth ]	+=	v[ dth ][ kth ] * nA[ dth ] ;
				for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
					vt[ ddth ][ kth ]	+=	v[ dth ][ kth ] * tA[ ddth ][ dth ] ;
    		}
    		p[ kth ]	=	( gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cid[ kth ] ] - 0.5 * rho[ kth ] * V2[ 0 ] ) ;
    		a[ kth ]	=	sqrt( gamma * p[ kth ] / rho[ kth ] ) ;
			//H[ kth ]	=	a[ kth ] * a[ kth ] / ( gamma - 1.0 ) + 0.5 * V2[ 0 ] ;
			H[ kth ]	=	( U[ unknownNum - 1 ][ cid[ kth ] ] + p[ kth ] ) / rho[ kth ] ;
    	}

   		// Roe Averages
		RT 			=	sqrt( rho[ 1 ] / rho[ 0 ] ) ;
		rho[ 2 ]	=	RT * rho[ 0 ] ;

		V2[ 0 ]		=	0.0 ;
		vn[ 2 ]		=	0.0 ;
		for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
			vt[ ddth ][ 2 ]	=	0.0 ;

		for ( dth = 0 ; dth < ndim ; dth++ )
		{
			v[ dth ][ 2 ]	=	( v[ dth ][ 0 ] + RT * v[ dth ][ 1 ] ) / ( 1.0 + RT ) ;

			V2[ 0 ]			+=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
			vn[ 2 ]			+=	v[ dth ][ 2 ] * nA[ dth ] ;

			for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
				vt[ ddth ][ 2 ]	+=	v[ dth ][ 2 ] * tA[ ddth ][ dth ] ;
		}
		H[ 2 ]		=	( H[ 0 ] + RT * H[ 1 ] ) / ( 1.0 + RT ) ;
		a[ 2 ]		=	sqrt( ( gamma - 1.0 ) * ( H[ 2 ] - 0.5 * V2[ 0 ] ) ) ;

		// Wave Strengths
		drho 		=	rho[ 1 ] - rho[ 0 ] ;
		dp 			=	p[ 1 ] - p[ 0 ] ;
		dvn 		=	vn[ 1 ] - vn[ 0 ] ;
		for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
			dvt[ ddth ]	=	vt[ ddth ][ 1 ] - vt[ ddth ][ 0 ] ;

		LdU[ 0 ]	=	( dp - rho[ 2 ] * a[ 2 ] * dvn ) / ( 2.0 * a[ 2 ] * a[ 2 ] ) ;
		LdU[ 1 ]	=	drho - dp / ( a[ 2 ] * a[ 2 ] ) ;
		LdU[ 2 ]	=	( dp + rho[ 2 ] * a[ 2 ] * dvn ) / ( 2.0 * a[ 2 ] * a[ 2 ] ) ;
		for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
			LdU[ 3 + ddth ]	=	rho[ 2 ] * dvt[ ddth ] ;

		// Wave speed
		ws[ 0 ]		=	fabs( vn[ 2 ] - a[ 2 ] ) ;
		ws[ 1 ] 	=	fabs( vn[ 2 ]          ) ;
		ws[ 2 ] 	=	fabs( vn[ 2 ] + a[ 2 ] ) ;
		for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
			ws[ 3 + ddth ] 	=	fabs( vn[ 2 ] ) ;

		// Harten's Entropy Fix JCP(1983), 49, pp357-393
		for ( kth = 0 ; kth < unknownNum ; kth++ )
			dws[ kth ] =	0.0 ;
		dws[ 0 ]	=	1.0 / 5.0 ;
		if ( ws[ 0 ] < dws[ 0 ] )
			ws[ 0 ]	=	0.5 * ( ws[ 0 ] * ws[ 0 ] / dws[ 0 ] + dws[ 0 ] ) ;
		dws[ 2 ]	=	1.0 / 5.0 ;
		if ( ws[ 2 ] < dws[ 2 ] )
			ws[ 2 ]	=	0.5 * ( ws[ 2 ] * ws[ 2 ] / dws[ 2 ] + dws[ 2 ] ) ;

		// Eigenvectors
		// zero Rv
		for ( kth = 0 ; kth < unknownNum ; kth++ )
			for ( kkth = 0 ; kkth < unknownNum ; kkth++ )
				Rv[ kth ][ kkth ]	=	0. ;

		for ( kth = 0 ; kth < 3 ; kth++ )
			Rv[ 0 ][ kth ]	=	1.0 ;

		for ( dth = 0 ; dth < ndim ; dth++ )
		{
			Rv[ dth + 1 ][ 0 ]	=	v[ dth ][ 2 ] - a[ 2 ] * nA[ dth ] ;
			Rv[ dth + 1 ][ 1 ]	=	v[ dth ][ 2 ] ;
			Rv[ dth + 1 ][ 2 ]	=	v[ dth ][ 2 ] + a[ 2 ] * nA[ dth ] ;
			for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
				Rv[ dth + 1 ][ 3 + ddth ]	=	tA[ ddth ][ dth ] ;
		}

		Rv[ unknownNum - 1 ][ 0 ]	=	H[ 2 ] - a[ 2 ] * vn[ 2 ] ;
		Rv[ unknownNum - 1 ][ 1 ]	=	V2[ 0 ] / 2.0 ;
		Rv[ unknownNum - 1 ][ 2 ]	=	H[ 2 ] + a[ 2 ] * vn[ 2 ] ;
		for ( ddth = 0 ; ddth < ( ndim - 1 ) ; ddth++ )
			Rv[ unknownNum - 1 ][ 3 + ddth ]	=	vt[ ddth ][ 2 ] ;

		// Dissipation Term
		for ( int i = 0 ; i < unknownNum ; i++ )
		{
			Diss[ i ] = 0.0 ;  
			for ( int j = 0 ; j < unknownNum ; j++ ) 
				Diss[ i ] +=	ws[ j ] * LdU[ j ] * Rv[ i ][ j ] ;
		}

		// Compute the flux
		for ( kth = 0 ; kth < 2 ; kth++ )
		{
			F[ 0 ][ kth ] 	=	rho[ kth ] * vn[ kth ] ;
			for ( dth = 0 ; dth < ndim ; dth++ )
				F[ 1 + dth ][ kth ] 	=	rho[ kth ] * vn[ kth ] * v[ dth ][ kth ] + p[ kth ] * nA[ dth ] ;
			F[ unknownNum - 1 ][ kth ] 	=	rho[ kth ] * vn[ kth ] * H[ kth ] ;
		}

		for ( kth = 0 ; kth < unknownNum ; kth++ )
			Flux[ kth ]	=	0.5 * ( F[ kth ][ 0 ] + F[ kth ][ 1 ] - Diss[ kth ] ) ;
	} else
	{
		if ( face_Typename == "inlet" )
		{
			// SuperSonic Inflow: fix density, velocity, pressure
			rho[ 2 ]	=	rho_inf ;

			V2[ 0 ] 	=	0.0 ;
			vn[ 2 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
			{
				v[ dth ][ 2 ]	=	v_inf[ dth ] ;

				V2[ 0 ] +=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
				vn[ 2 ]	+=	v[ dth ][ 2 ] * nA[ dth ] ;
			} 
   			p[ 2 ]	=	P_inf ;
		} else if ( face_Typename == "outlet" )
		{
			// SuperSonic outflow: Extrapolate density, velocity, energy
			rho[ 2 ] 	=	U[ 0 ][ cid[ 0 ] ] ;

			V2[ 0 ] 	=	0.0 ;
			vn[ 2 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
			{
				v[ dth ][ 2 ]	=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] ;

				V2[ 0 ] +=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
				vn[ 2 ]	+=	v[ dth ][ 2 ] * nA[ dth ] ;
			} 
			p[ 2 ]	=	( gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cid[ 0 ] ] - 0.5 * rho[ 2 ] * V2[ 0 ] ) ;
		} else if ( face_Typename == "free_boundary" )
		{
			// free boundary:
			rho[ 2 ]	=	rho_inf ;

			V2[ 0 ] 	=	0.0 ;
			V2[ 1 ]		=	0.0 ;
			vn[ 2 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
			{
				v[ dth ][ 2 ]	=	v_inf[ dth ] ;

				V2[ 0 ] +=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
				V2[ 1 ] +=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] * U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] ;
				vn[ 2 ]	+=	v[ dth ][ 2 ] * nA[ dth ] ;
			}

   			//p[ 2 ]	=	P_inf ;
   			p[ 2 ]	=	( gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cid[ 0 ] ] - 0.5 * rho[ 2 ] * V2[ 1 ] ) ;
		} else if ( face_Typename == "symmetric" )
		{
			// Slip boundary condition
			rho[ 2 ] 	=	U[ 0 ][ cid[ 0 ] ] ;

			vn[ 0 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
				vn[ 0 ]	+=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] * nA[ dth ] ;

			V2[ 0 ] 	=	0.0 ;
			V2[ 1 ]		=	0.0 ;
			vn[ 2 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
			{
				v[ dth ][ 2 ]	=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] - vn[ 0 ] * nA[ dth ] ;

				V2[ 0 ] +=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
				V2[ 1 ] +=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] * U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] ;
				vn[ 2 ]	+=	v[ dth ][ 2 ] * nA[ dth ] ;
			} 
			p[ 2 ]	=	( gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cid[ 0 ] ] - 0.5 * rho[ 2 ] * V2[ 1 ] ) ;
		} else if ( face_Typename == "neumann" )
		{
			rho[ 2 ] 	=	U[ 0 ][ cid[ 0 ] ] ;
			V2[ 0 ] 	=	0.0 ;
			vn[ 2 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
			{
				v[ dth ][ 2 ]	=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] ;

				V2[ 0 ] +=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
				vn[ 2 ]	+=	v[ dth ][ 2 ] * nA[ dth ] ;
			} 
			p[ 2 ]	=	( gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cid[ 0 ] ] - 0.5 * rho[ 2 ] * V2[ 0 ] ) ;		
		} else if ( face_Typename == "wall" )
		{
			// Slip boundary condition
			rho[ 2 ] 	=	U[ 0 ][ cid[ 0 ] ] ;

			vn[ 0 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
				vn[ 0 ]	+=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] * nA[ dth ] ;

			V2[ 0 ]		=	0.0 ;
			V2[ 1 ]		=	0.0 ;
			vn[ 2 ]		=	0.0 ;
			for ( dth = 0 ; dth < ndim ; dth++ )
			{
				v[ dth ][ 2 ]	=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] - vn[ 0 ] * nA[ dth ] ;

				V2[ 0 ] +=	v[ dth ][ 2 ] * v[ dth ][ 2 ] ;
				V2[ 1 ] +=	U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] * U[ 1 + dth ][ cid[ 0 ] ] / U[ 0 ][ cid[ 0 ] ] ;
				vn[ 2 ]	+=	v[ dth ][ 2 ] * nA[ dth ] ;
			} 
			p[ 2 ]	=	( gamma - 1.0 ) * ( U[ unknownNum - 1 ][ cid[ 0 ] ] - 0.5 * rho[ 2 ] * V2[ 1 ] ) ;
		}

   		a[ 2 ]	=	sqrt ( gamma * p[ 2 ] / rho[ 2 ] ) ;
   		H[ 2 ]	=	a[ 2 ] * a[ 2 ] / ( gamma - 1.0 ) + 0.5 * V2[ 0 ] ;

		Flux[ 0 ]	=	rho[ 2 ] * vn[ 2 ] ;
		for ( dth = 0 ; dth < ndim ; dth++ )
			Flux[ 1 + dth ]	=	rho[ 2 ] * vn[ 2 ] * v[ dth ][ 2 ] + p[ 2 ] * nA[ dth ] ;
		Flux[ unknownNum - 1 ]	=	rho[ 2 ] * vn[ 2 ] * H[ 2 ] ;
	}	
}


bool EulerRoe::Calculate_MaxTol( double *MaxTol, int unknownNum, int cellNum, double **Tolerance )
{
	int 	kth, cth ;
	double 	buffer ;
	bool	flg = true ;

	for ( kth = 0 ; kth < unknownNum ; kth++ )
		MaxTol[ kth ]	=	0.0 ;

	for ( cth = 0 ; cth < cellNum ; cth++ )
	{
		for ( kth = 0 ; kth < unknownNum ; kth++ )
			if ( Tolerance[ kth ][ cth ] > MaxTol[ kth ] )
				MaxTol[ kth ]	=	Tolerance[ kth ][ cth ] ;
	}

	MPI_Barrier( MPI_COMM_WORLD ) ;
	for ( kth = 0 ; kth < unknownNum ; kth++ )
	{
		buffer	=	MaxTol[ kth ] ;

		MPI_Allreduce( &buffer, &MaxTol[ kth ], 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD ) ;
		if ( MaxTol[ kth ] > tolerance )
			flg =	false ;
	}

	return flg ;
}