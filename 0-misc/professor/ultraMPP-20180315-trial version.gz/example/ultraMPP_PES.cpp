#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <mpi.h>
#include "json.hpp"
#include "ultraMPP.h"

using namespace std ;
using nlohmann::json ;

int cpu_size, myid ;

int main( int argc, char * argv[] )
{
	ultraMPP PDE_solver ;

	PDE_solver.initial( argc,argv, &myid, &cpu_size ) ;
	PDE_solver.load_mesh( "JsonInput.json" ) ;

	int 	Neumann_bc_tag    = PDE_solver.get_bc_mapping( "neumann") ;
	int 	Dirichlet_bc_tag1 = PDE_solver.get_bc_mapping( "dirichlet1" ) ;
	int 	Dirichlet_bc_tag2 = PDE_solver.get_bc_mapping( "dirichlet2" ) ;

	int ndim = PDE_solver.Mesh.ndim;
	double *potential, *charge, *cpiID;
	double *face_data;

	int Tag_EF[ndim];
	string EF_name[3];
	EF_name[0] = "EFx";
	EF_name[1] = "EFy";
	EF_name[2] = "EFz";

	double **EF;
	EF = new double*[ndim];

	int Tag_Cha = PDE_solver.set_parallel_cell_data(&charge, "ChargeDen");
	int Tag_pot = PDE_solver.set_parallel_cell_data(&potential, "Potential");
	for( int i = 0; i < ndim; i++)
		Tag_EF[i] = PDE_solver.set_parallel_cell_data(&EF[i], EF_name[i]);

	int Tag_Cpu = PDE_solver.set_parallel_cell_data(&cpiID, "cpuid");
	int Tag_Fac = PDE_solver.set_face_data(&face_data, "face_data");

//--Set output data
	PDE_solver.set_output("test.dat");
	PDE_solver.set_output(Tag_Cha);
	PDE_solver.set_output(Tag_pot);

	for( int i = 0; i < ndim; i++) 	PDE_solver.set_output(Tag_EF[i]);

	PDE_solver.set_output(Tag_Cpu);

	for ( int cth = 0 ; cth < PDE_solver.Mesh.cell_number ; cth++ )
	{
		Cell *cell		=	PDE_solver.get_cell( cth ) ;
		cpiID[ cth ]	=	cell->mpi_id ;
		charge[ cth ]	=	1.0e10 ; // unit # m^-3
	}

	PDE_solver.apply_linear_solver_setting();

	PDE_solver.before_matrix_construction() ;

	PDE_solver.add_laplacian_op(1.0) ;

	PDE_solver.finish_matrix_construction() ;

	for ( int fth = 0 ; fth < PDE_solver.Mesh.face_number; fth++ ) face_data[ fth ] = 0.0 ;

	PDE_solver.set_bc_value( Dirichlet_bc_tag1, 0.0, face_data );

	PDE_solver.set_bc_value( Dirichlet_bc_tag2, 10.0, face_data );

//---------------------------------------------------
	for( int iters = 0; iters < 5; iters++){
		PDE_solver.before_source_term_construction() ;

		PDE_solver.set_source_term(charge, face_data);

		if(iters > 0)
		PDE_solver.add_non_orthogornal_correction(EF);

		PDE_solver.finish_source_term_construction() ;

		PDE_solver.get_solution( potential ) ;

		PDE_solver.get_gradient_least( face_data, EF ) ;
	};
//---------------------------------------------------

	for ( int i = 0; i < ndim; i++)
	for ( int ith = 0 ; ith < PDE_solver.Mesh.cell_number ; ith++ ) EF[ i ][ ith ] = - EF[ i ][ ith ] ;

	PDE_solver.write_output( "time0" ) ;

	return 0 ;
}


//--content in JsonInput.json
/*
{
"mesh":
	{
		"geometry": "2D",
		"scale": 1.0,
		"structured_mesh":
		{
			"nx": 101,
			"ny": 101,
			"dx": 0.001,
			"dy": 0.001,
			"boundary_settings": [ "dirichlet1", "dirichlet2", "neumann", "neumann" ]
		}
	}
}
*/
